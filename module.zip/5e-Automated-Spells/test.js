// // 

// main()

// async function main(){
//     new Dialog({
//         title: "Alter Self Aquatic Adaption?",
//         content: "Are you using this spells for Aquatic Adaption",
//         buttons: {
//           yes: {
//             label: "Yes",
//             callback: () => {}
//           },
//           no: {
//             label: "No",
//             callback: () => {change()}
//           }
//         },
//           default: 'No',
//       }).render(true)
// }


// async function change(){
//     new Dialog({
//         title: "Alter Self Change Appearance?",
//         content: "Are you using this spells for Change Appearance",
//         buttons: {
//           yes: {
//             label: "Yes",
//             callback: () => {console.log("Change")}
//           },
//           no: {
//             label: "No",
//             callback: () => {console.log("No Change")}
//           }
//         },
//           default: 'No',
//       }).render(true)
// }