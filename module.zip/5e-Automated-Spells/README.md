Automating Spells

Goals
* Automating Summoning
* Add more automation to spells for the end of turn
